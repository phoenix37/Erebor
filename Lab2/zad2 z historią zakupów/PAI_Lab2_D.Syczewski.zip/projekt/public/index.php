<?php
error_reporting(E_ALL); // komunikaty diagnostyczne – bez wzgl du ę
ini_set('display_errors', 1); // na ustawienia serwera
require_once '../app/init.php';
$app = new App();