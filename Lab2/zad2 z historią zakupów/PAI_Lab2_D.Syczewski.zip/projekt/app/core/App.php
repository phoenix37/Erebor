<?php
class App
{
protected $controller = 'home'; /* http://www.cos.pl/home */
protected $method = 'index'; /* http://www.cos.pl/home/index */
protected $params = []; /* http://www.cos.pl/home/index/5/ */
public function __construct()
{
$url = $this->parseUrl();
var_dump($url);
}
protected function parseUrl()
{
if (isset($_GET['url']))
return explode('/', filter_var(rtrim($_GET['url'], '/'),
FILTER_SANITIZE_URL));
}
}