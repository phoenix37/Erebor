<?php

/* ProductDemoBundle:Default:index.html.twig */
class __TwigTemplate_54d7def86f574c67783bad9d0cd7f5ecd63724e74d88966319fdd9ae249e5bb6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::base.html.twig", "ProductDemoBundle:Default:index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        // line 3
        echo "    <table border=1>
    <tr><th>Name</th><th>Price</th><th>Description</th></tr>
    ";
        // line 5
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["products"]) ? $context["products"] : $this->getContext($context, "products")));
        foreach ($context['_seq'] as $context["_key"] => $context["p"]) {
            // line 6
            echo "        <tr>
            <td>";
            // line 7
            echo twig_escape_filter($this->env, $this->getAttribute($context["p"], "name", array()), "html", null, true);
            echo "</td>
            <td>";
            // line 8
            echo twig_escape_filter($this->env, $this->getAttribute($context["p"], "price", array()), "html", null, true);
            echo "</td>
            <td>";
            // line 9
            echo twig_escape_filter($this->env, $this->getAttribute($context["p"], "description", array()), "html", null, true);
            echo "</td>

            <td><a href=";
            // line 11
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("product_demo_edit", array("id" => $this->getAttribute($context["p"], "id", array()))), "html", null, true);
            echo ">Edit</a></td>
            <td><a href=";
            // line 12
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("product_demo_delete", array("id" => $this->getAttribute($context["p"], "id", array()))), "html", null, true);
            echo ">Del</a></td>


        </tr>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['p'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 17
        echo "    <table>

    <a href=";
        // line 19
        echo $this->env->getExtension('routing')->getPath("product_demo_add");
        echo ">Add product</a>
";
    }

    public function getTemplateName()
    {
        return "ProductDemoBundle:Default:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  74 => 19,  70 => 17,  59 => 12,  55 => 11,  50 => 9,  46 => 8,  42 => 7,  39 => 6,  35 => 5,  31 => 3,  28 => 2,  11 => 1,);
    }
}
