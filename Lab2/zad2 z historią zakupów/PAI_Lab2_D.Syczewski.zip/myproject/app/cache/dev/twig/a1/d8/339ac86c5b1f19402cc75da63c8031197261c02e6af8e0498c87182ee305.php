<?php

/* AppBundle:Default:history.html.twig */
class __TwigTemplate_a1d8339ac86c5b1f19402cc75da63c8031197261c02e6af8e0498c87182ee305 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::base.html.twig", "AppBundle:Default:history.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        // line 3
        echo "    <table border=1>
    <tr><th>Name</th><th>Pieces</th></tr>
    ";
        // line 5
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["historys"]) ? $context["historys"] : $this->getContext($context, "historys")));
        foreach ($context['_seq'] as $context["_key"] => $context["p"]) {
            // line 6
            echo "        <tr>
            <td>";
            // line 7
            echo twig_escape_filter($this->env, $this->getAttribute($context["p"], "name", array()), "html", null, true);
            echo "</td>
            <td>";
            // line 8
            echo twig_escape_filter($this->env, $this->getAttribute($context["p"], "pieces", array()), "html", null, true);
            echo "</td>
        </tr>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['p'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 11
        echo "    <table>
";
    }

    public function getTemplateName()
    {
        return "AppBundle:Default:history.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  55 => 11,  46 => 8,  42 => 7,  39 => 6,  35 => 5,  31 => 3,  28 => 2,  11 => 1,);
    }
}
