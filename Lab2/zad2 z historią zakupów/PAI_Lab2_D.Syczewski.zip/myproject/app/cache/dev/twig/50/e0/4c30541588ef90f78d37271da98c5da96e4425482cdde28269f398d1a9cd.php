<?php

/* AppBundle:Default:index.html.twig */
class __TwigTemplate_50e04c30541588ef90f78d37271da98c5da96e4425482cdde28269f398d1a9cd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::base.html.twig", "AppBundle:Default:index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        // line 3
        echo "    <table border=1>
    <tr><th>Name</th><th>Price</th><th>Description</th></tr>
    ";
        // line 5
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["products"]) ? $context["products"] : $this->getContext($context, "products")));
        foreach ($context['_seq'] as $context["_key"] => $context["p"]) {
            // line 6
            echo "        <tr>
            <td>";
            // line 7
            echo twig_escape_filter($this->env, $this->getAttribute($context["p"], "name", array()), "html", null, true);
            echo "</td>
            <td>";
            // line 8
            echo twig_escape_filter($this->env, $this->getAttribute($context["p"], "price", array()), "html", null, true);
            echo "</td>
            <td>";
            // line 9
            echo twig_escape_filter($this->env, $this->getAttribute($context["p"], "description", array()), "html", null, true);
            echo "</td>
            <td><a href=";
            // line 10
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("product_demo_edit", array("id" => $this->getAttribute($context["p"], "id", array()))), "html", null, true);
            echo ">Edit product</a></td>
            <td><a href=";
            // line 11
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("product_demo_delete", array("id" => $this->getAttribute($context["p"], "id", array()))), "html", null, true);
            echo ">Delete product</a></td>
            <td><a href=";
            // line 12
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("product_demo_buy", array("id" => $this->getAttribute($context["p"], "id", array()))), "html", null, true);
            echo ">Buy product</a></td>
        </tr>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['p'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 15
        echo "    <table>

    <td><a href=";
        // line 17
        echo $this->env->getExtension('routing')->getPath("product_demo_add");
        echo ">Add product</a></td>
    <td><a href=";
        // line 18
        echo $this->env->getExtension('routing')->getPath("producthistory_homepage");
        echo ">History shopping</a></td>
";
    }

    public function getTemplateName()
    {
        return "AppBundle:Default:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  79 => 18,  75 => 17,  71 => 15,  62 => 12,  58 => 11,  54 => 10,  50 => 9,  46 => 8,  42 => 7,  39 => 6,  35 => 5,  31 => 3,  28 => 2,  11 => 1,);
    }
}
