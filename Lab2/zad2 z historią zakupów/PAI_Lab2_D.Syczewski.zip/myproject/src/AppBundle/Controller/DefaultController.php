<?php

namespace AppBundle\Controller;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use AppBundle\Entity\Product;
use AppBundle\Entity\History;

class DefaultController extends Controller
{


     /**
     * @Route("/productdemo/", name="product_demo_homepage")
     */
    public function indexAction()
    {
        $products = $this->getDoctrine()
            ->getRepository('AppBundle:Product')
            ->findAllOrderedByName();
        return $this->render('AppBundle:Default:index.html.twig',
            array('products' => $products));
    }

    /**
     * @Route("/producthistory/", name="producthistory_homepage")
     */
    public function historyAction()
    {
        $historys = $this->getDoctrine()
            ->getRepository('AppBundle:History')
            ->findAllOrderedByName();
        return $this->render('AppBundle:Default:history.html.twig',
            array('historys' => $historys));
    }

    /**
     * @Route("/product_demo_add", name="product_demo_add")
     */
    public function addAction(Request $request)
    {
        $product = new Product();
        $product->setName('A Foo Bar');
        $product->setPrice('19.99');
        $product->setDescription('Lorem ipsum dolor');
        $form = $this->createFormBuilder($product)
            ->add('name', 'text')
            ->add('price', 'money')
            ->add('description', 'textarea')
            ->add('save', 'submit', array('label' => 'Create product'))
            ->getForm();
        $form->handleRequest($request);
        if ($form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->persist($product);
            $em->flush();
            return $this->redirectToRoute('product_demo_homepage');
        }
        return $this->render('AppBundle:Default:product_form.html.twig', array(
            'form' => $form->createView(),
        ));
    }

    /**
     * @Route("/product_demo_edit/{id}", name="product_demo_edit")
     */
    public function editAction(Request $request, $id)
    {
        $em = $this->getDoctrine()->getManager();
        $product = $em->getRepository('AppBundle:Product')->find($id);
        if (!$product) {
            throw $this->createNoFoundException(
                'No product found for id ' . $id
            );
        }
        $form = $this->createFormBuilder($product)
            ->add('name', 'text')
            ->add('price', 'money')
            ->add('description', 'textarea')
            ->add('save', 'submit', array('label' => 'Change product'))
            ->getForm();
        $form->handleRequest($request);
        if ($form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->persist($product);
            $em->flush();
            return $this->redirectToRoute('product_demo_homepage');
        }
        return $this->
        render('AppBundle:Default:product_form.html.twig', array(
            'form' => $form->createView(),
        ));
    }

    /**
     * @Route("/product_demo_buy/{id}", name="product_demo_buy")
     */
    public function buyAction(Request $request, $id)
    {
        $em = $this->getDoctrine()->getManager();
        $product = $em->getRepository('AppBundle:Product')->find($id);
        if (!$product) {
            throw $this->createNoFoundException(
                'No product found for id ' . $id
            );
        }
        $nazwa = $product->getName();
        /*$form = $this->createFormBuilder($product)
            ->add('name', 'text')
            ->getForm();*/
        //$form2->handleRequest($request);
        $historys = new History();
        $historys->setName($nazwa);
        $form = $this->createFormBuilder($historys)
            ->add('name', 'text')
            ->add('pieces','textarea')
            ->add('save', 'submit', array('label' => 'Buy product'))
            ->getForm();
        $form->handleRequest($request);
        if ($form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->persist($historys);
            $em->flush();
            return $this->redirectToRoute('product_demo_homepage');
        }
        return $this->
        render('AppBundle:Default:product_form.html.twig', array(
            'form' => $form->createView(),
        ));
    }



    /**
     * @Route("/product_demo_delete/{id}", name="product_demo_delete")
     */

    public function deleteAction($id)
    {
        $em = $this->getDoctrine()->getManager();
        $product = $em->getRepository('AppBundle:Product')->find($id);
        if ($product) {
            $em->remove($product);
            $em->flush();
        } else {
            throw $this->createNoFoundException(
                'No product found for id '.$id
            );
        }
        return $this->redirectToRoute('product_demo_homepage');
    }

}
