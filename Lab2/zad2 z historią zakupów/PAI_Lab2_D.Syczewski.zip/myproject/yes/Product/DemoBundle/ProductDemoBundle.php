<?php

namespace Product\DemoBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ProductDemoBundle extends Bundle
{
}
