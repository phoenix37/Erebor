/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jpa.session;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jpa.entities.ProjektUzytkownicy;

/**
 *
 * @author Pawel
 */
@Stateless
public class ProjektUzytkownicyFacade extends AbstractFacade<ProjektUzytkownicy> {
    @PersistenceContext(unitName = "ProjektNaZajeciaPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public ProjektUzytkownicyFacade() {
        super(ProjektUzytkownicy.class);
    }
    
}
