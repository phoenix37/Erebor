package jpa;

import jpa.entities.ProjektUzytkownicy;
import jpa.util.JsfUtil;
import jpa.util.PaginationHelper;
import jpa.session.ProjektUzytkownicyFacade;

import java.io.Serializable;
import java.util.List;
import java.util.ResourceBundle;
import javax.ejb.EJB;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;
import javax.faces.model.DataModel;
import javax.faces.model.ListDataModel;
import javax.faces.model.SelectItem;

@Named("projektUzytkownicyController")
@SessionScoped
public class ProjektUzytkownicyController implements Serializable {

    private ProjektUzytkownicy current;
    private DataModel items = null;
    @EJB
    private jpa.session.ProjektUzytkownicyFacade ejbFacade;
    private PaginationHelper pagination;
    private int selectedItemIndex;
    private String login;
    private String password;

    public ProjektUzytkownicyController() {
    }

    public ProjektUzytkownicy getSelected() {
        if (current == null) {
            current = new ProjektUzytkownicy();
            selectedItemIndex = -1;
        }
        return current;
    }

    private ProjektUzytkownicyFacade getFacade() {
        return ejbFacade;
    }

    public PaginationHelper getPagination() {
        if (pagination == null) {
            pagination = new PaginationHelper(10) {
                @Override
                public int getItemsCount() {
                    return getFacade().count();
                }

                @Override
                public DataModel createPageDataModel() {
                    return new ListDataModel(getFacade().findRange(new int[]{getPageFirstItem(), getPageFirstItem() + getPageSize()}));
                }
            };
        }
        return pagination;
    }
    
    public String getLogin() {
        return this.login;
    }
    
    public void setLogin(String login) {
        this.login = login;
    }
    
    public String getPassword() {
        return this.password;
    }
    
    public void setPassword(String password) {
        this.password = password;
    }

    public String prepareList() {
        recreateModel();
        return "List";
    }

    public String prepareView() {
        current = (ProjektUzytkownicy) getItems().getRowData();
        selectedItemIndex = pagination.getPageFirstItem() + getItems().getRowIndex();
        return "View";
    }

    public String prepareRegister() {
        current = new ProjektUzytkownicy();
        selectedItemIndex = -1;
        return "Register";
    }
    
    public String loginToApp() {
        ProjektUzytkownicy user = null;
        List<ProjektUzytkownicy> users = getFacade().findAll();
        for(ProjektUzytkownicy temp_user : users) {
            if(temp_user.getLogin().equals(login)) {
                user = temp_user;
            }
        }
        if(user == null) {
            JsfUtil.addErrorMessage(ResourceBundle.getBundle("/resources/Bundle").getString("UserDoesNotExist"));
            return "Login";
        }      
        if(!(user.getHaslo().equals(password))) {
            JsfUtil.addErrorMessage(ResourceBundle.getBundle("/resources/Bundle").getString("DifferentPasswords"));
            return "Login";
        }           
        if(!user.getAktywny()) {
            JsfUtil.addErrorMessage(ResourceBundle.getBundle("/resources/Bundle").getString("UserDisabled"));
            return "Login";
        }
        JsfUtil.addSuccessMessage(ResourceBundle.getBundle("/resources/Bundle").getString("LoginSuccesfull"));
        if(user.getRola().equals("administrator")) {
            return "List";
        } else {
            return "View";
        }
    }

    public String create() {
        if(!(current.getHaslo().equals(password))) {
            JsfUtil.addErrorMessage(ResourceBundle.getBundle("/resources/Bundle").getString("PasswordsDoesNotEqual"));
            return null;
        }
        try {
            current.setAktywny(true);
            getFacade().create(current);
            JsfUtil.addSuccessMessage(ResourceBundle.getBundle("/resources/Bundle").getString("ProjektUzytkownicyCreated"));
            return prepareRegister();
        } catch (Exception e) {
            JsfUtil.addErrorMessage(e, ResourceBundle.getBundle("/resources/Bundle").getString("PersistenceErrorOccured"));
            return null;
        }
    }

    public String disable() {
        current = (ProjektUzytkownicy) getItems().getRowData();
        try {
            current.setAktywny(false);
            getFacade().edit(current);
            selectedItemIndex = pagination.getPageFirstItem() + getItems().getRowIndex();
            JsfUtil.addSuccessMessage(ResourceBundle.getBundle("/resources/Bundle").getString("ProjektUzytkownicyUpdated"));
            return "List";
        } catch (Exception e) {
            JsfUtil.addErrorMessage(e, ResourceBundle.getBundle("/resources/Bundle").getString("PersistenceErrorOccured"));
            return null;
        }
    }
    
    public String enable() {
        current = (ProjektUzytkownicy) getItems().getRowData();
        try {
            current.setAktywny(true);
            getFacade().edit(current);
            selectedItemIndex = pagination.getPageFirstItem() + getItems().getRowIndex();
            JsfUtil.addSuccessMessage(ResourceBundle.getBundle("/resources/Bundle").getString("ProjektUzytkownicyUpdated"));
            return "List";
        } catch (Exception e) {
            JsfUtil.addErrorMessage(e, ResourceBundle.getBundle("/resources/Bundle").getString("PersistenceErrorOccured"));
            return null;
        }
    }

    public DataModel getItems() {
        if (items == null) {
            items = getPagination().createPageDataModel();
        }
        return items;
    }

    private void recreateModel() {
        items = null;
    }

    public String next() {
        getPagination().nextPage();
        recreateModel();
        return "List";
    }

    public String previous() {
        getPagination().previousPage();
        recreateModel();
        return "List";
    }

    public SelectItem[] getItemsAvailableSelectMany() {
        return JsfUtil.getSelectItems(ejbFacade.findAll(), false);
    }

    public SelectItem[] getItemsAvailableSelectOne() {
        return JsfUtil.getSelectItems(ejbFacade.findAll(), true);
    }

    public ProjektUzytkownicy getProjektUzytkownicy(java.lang.Integer id) {
        return ejbFacade.find(id);
    }

    @FacesConverter(forClass = ProjektUzytkownicy.class)
    public static class ProjektUzytkownicyControllerConverter implements Converter {

        @Override
        public Object getAsObject(FacesContext facesContext, UIComponent component, String value) {
            if (value == null || value.length() == 0) {
                return null;
            }
            ProjektUzytkownicyController controller = (ProjektUzytkownicyController) facesContext.getApplication().getELResolver().
                    getValue(facesContext.getELContext(), null, "projektUzytkownicyController");
            return controller.getProjektUzytkownicy(getKey(value));
        }

        java.lang.Integer getKey(String value) {
            java.lang.Integer key;
            key = Integer.valueOf(value);
            return key;
        }

        String getStringKey(java.lang.Integer value) {
            StringBuilder sb = new StringBuilder();
            sb.append(value);
            return sb.toString();
        }

        @Override
        public String getAsString(FacesContext facesContext, UIComponent component, Object object) {
            if (object == null) {
                return null;
            }
            if (object instanceof ProjektUzytkownicy) {
                ProjektUzytkownicy o = (ProjektUzytkownicy) object;
                return getStringKey(o.getId());
            } else {
                throw new IllegalArgumentException("object " + object + " is of type " + object.getClass().getName() + "; expected type: " + ProjektUzytkownicy.class.getName());
            }
        }
    }
}
