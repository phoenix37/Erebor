<?php

namespace Rest\DemoBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class RestDemoBundle extends Bundle
{
}
