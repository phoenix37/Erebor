<?php
namespace Rest\DemoBundle\Handler;
use Doctrine\Common\Persistence\ObjectManager;
use Symfony\Component\Form\FormFactoryInterface;
use Rest\DemoBundle\Model\DailyNoteInterface;
use Rest\DemoBundle\Form\DailyNoteType;
use Rest\DemoBundle\Exception\InvalidFormException;
class DailyNoteHandler implements DailyNoteHandlerInterface
{
private $om;
private $entityClass;
private $repository;
private $formFactory;

public function __construct(ObjectManager $om, $entityClass, FormFactoryInterface $formFactory)
{
	$this->om = $om;
	$this->entityClass = $entityClass;
	$this->repository = $this->om->getRepository($this->entityClass);
	$this->formFactory = $formFactory;
}
/**
* Create a new DailyNote.
*
* @param array $parameters
*
* @return DailyNoteInterface
*/
public function post(array $parameters)
{
$note = $this->createNote();
return $this->processForm($note, $parameters, 'POST');
}
/**
* Processes the form.
*
* @param DailyNoteInterface $note
* @param array $parameters
* @param String $method
*
* @return DailyNoteInterface
*
* @throws \Rest\DemoBundle\Exception\InvalidFormException
*/
private function processForm(DailyNoteInterface $note, array $parameters,
$method = "PUT")
{
$form = $this->formFactory->create(new DailyNoteType(), $note,
array('method' => $method));
$form->submit($parameters, 'PATCH' !== $method);
if ($form->isValid()) {
$note = $form->getData();
$this->om->persist($note);
$this->om->flush($note);
}
return $note;
throw new InvalidFormException('Invalid submitted data', $form);
}

/**
* Get a list of Pages.
*
* @return array
*/
public function all()
{
return $this->repository->findAll();
}
private function createNote()
{
return new $this->entityClass();
}
}