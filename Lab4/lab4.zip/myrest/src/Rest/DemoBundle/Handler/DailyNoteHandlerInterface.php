<?php
namespace Rest\DemoBundle\Handler;
use Rest\DemoBundle\Model\DailyNoteInterface;
Interface DailyNoteHandlerInterface
{
/**
* Get a DailyNote given the identifier
*
* @api
*
* @param mixed $id
*
* @return DailyNoteInterface
*/
//public function get($id);

/**
* Post DailyNote, creates a new DailyNote.
*
* @param array $parameters
*
* @return DailyNoteInterface
*/
public function post(array $parameters);
}