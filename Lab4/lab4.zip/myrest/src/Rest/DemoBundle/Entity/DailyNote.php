<?php
namespace Rest\DemoBundle\Entity;
use Doctrine\ORM\Mapping as ORM;
use Rest\DemoBundle\Model\DailyNoteInterface;
/**
* @ORM\Entity
* @ORM\Table(name="dailynotes")
*/
class DailyNote implements DailyNoteInterface
{
/**
* @ORM\Column(type="integer")
* @ORM\Id
* @ORM\GeneratedValue(strategy="AUTO")
*/
protected $id;
/**
* @ORM\Column(type="string", length=255)
*/
protected $imgUrl;
/**
* @ORM\Column(type="date")
*/
protected $date;
/**
* @ORM\Column(type="text")
*/
protected $description;
/**
* @ORM\Column(type="integer")
*/
protected $stars;

/**
* @ORM\Column(type="boolean")
*/
protected $evaluated;

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set imgUrl
     *
     * @param string $imgUrl
     * @return DailyNote
     */
    public function setImgUrl($imgUrl)
    {
        $this->imgUrl = $imgUrl;

        return $this;
    }

    /**
     * Get imgUrl
     *
     * @return string 
     */
    public function getImgUrl()
    {
        return $this->imgUrl;
    }

    /**
     * Set date
     *
     * @param \DateTime $date
     * @return DailyNote
     */
    public function setDate($date)
    {
        $this->date = $date;

        return $this;
    }

    /**
     * Get date
     *
     * @return \DateTime 
     */
    public function getDate()
    {
        return $this->date;
    }

    /**
     * Set description
     *
     * @param string $description
     * @return DailyNote
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     * @return string 
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Set stars
     *
     * @param integer $stars
     * @return DailyNote
     */
    public function setStars($stars)
    {
        $this->stars = $stars;

        return $this;
    }

    /**
     * Get stars
     *
     * @return integer 
     */
    public function getStars()
    {
        return $this->stars;
    }

    /**
     * Set evaluated
     *
     * @param boolean $evaluated
     * @return DailyNote
     */
    public function setEvaluated($evaluated)
    {
        $this->evaluated = $evaluated;

        return $this;
    }

    /**
     * Get evaluated
     *
     * @return boolean 
     */
    public function getEvaluated()
    {
        return $this->evaluated;
    }
}
