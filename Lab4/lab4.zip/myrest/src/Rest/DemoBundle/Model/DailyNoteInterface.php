<?php
namespace Rest\DemoBundle\Model;
interface DailyNoteInterface {
/**
* Set imgUrl
*
* @param string $imgUrl
* @return DailyNoteInterface
*/
public function setImgUrl($imgUrl);
/**
* Get imgUrl
*
* @return string
*/
public function getImgUrl();
/**
* Set date
*
* @param \DateTime $date
* @return DailyNoteInterface
*/
public function setDate($date);
/**
* Get date
*
* @return \DateTime
*/
public function getDate();
/**
* Set description
*
* @param string $description
* @return DailyNoteInterface
*/
public function setDescription($description);
/**
* Get description
*
* @return string
*/
public function getDescription();
/**
* Set stars
*
* @param integer $stars
* @return DailyNoteInterface
*/
public function setStars($stars);
/**
* Get stars
*
* @return integer
*/
public function getStars();
/**
* Set evaluated
*
* @param boolean $evaluated
* @return DailyNoteInterface
*/
public function setEvaluated($evaluated);

/**
* Get evaluated
*
* @return boolean
*/
public function getEvaluated();
}