<?php

namespace Rest\DemoBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;

class DailyNoteType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('imgUrl', 'text')
            ->add('date', 'date', array( 'widget' => 'single_text', 'format' =>
'yyyy-MM-dd',))
            ->add('description', 'textarea')
            ->add('stars', 'number')
            ->add('evaluated', 'checkbox')
        ;
    }
    
    /**
     * @param OptionsResolverInterface $resolver
     */
    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Rest\DemoBundle\Entity\DailyNote',
            'csrf_protection' => false
        ));
    }

    /**
     * @return string
     */
    public function getName()
    {
        return 'rest_demobundle_dailynote';
    }
}
