<?php
namespace Rest\DemoBundle\Controller;
use FOS\RestBundle\Controller\FOSRestController;
use Symfony\Component\HttpFoundation\Request;

use FOS\RestBundle\Util\Codes;
use FOS\RestBundle\Controller\Annotations;
use Rest\DemoBundle\Exception\InvalidFormException;
use Rest\DemoBundle\Form\DailyNoteType;
use Rest\DemoBundle\Model\DailyNoteInterface;


class DailyNoteController extends FOSRestController {

	public function optionsNotesAction()
	{
		return null;
	}

	/**
	* List all notes.
	*
	* @Annotations\View(
	* templateVar="notes"
	* )
	*
	* @return array
	*/
	public function getNotesAction()
	{
		return $this->container->get('rest_demo.dailynote.handler')->all();
	}

	public function getNoteAction($id) { }
	
	/**
	* Create a DailyNote from the submitted data.
	*
	* @Annotations\View(
	* statusCode = Codes::HTTP_BAD_REQUEST
	* )
	*
	* @return FormTypeInterface|RouteRedirectView
	*/
	public function postNoteAction(Request $request)
	{
		try {
			$newNote = $this->container->get('rest_demo.dailynote.handler')->post(
			$request->request->all()
			);
			$routeOptions = array(
			'id' => $newNote->getId(),
			'_format' => $request->get('_format')
			);
			return $this->routeRedirectView('api_1_get_note', $routeOptions,
			Codes::HTTP_CREATED);
		} catch (InvalidFormException $exception) {
			return array('form' => $exception->getForm());
		}
	}


	public function putNoteAction(Request $request, $id) { }
	public function deleteNoteAction(Request $request, $id) { }
}