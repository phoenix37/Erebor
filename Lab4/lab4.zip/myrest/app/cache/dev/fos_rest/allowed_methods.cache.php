<?php return array (
  'api_1_options_notes' => 
  array (
    0 => 'OPTIONS',
    1 => 'GET',
    2 => 'POST',
  ),
  'api_1_get_notes' => 
  array (
    0 => 'OPTIONS',
    1 => 'GET',
    2 => 'POST',
  ),
  'api_1_post_note' => 
  array (
    0 => 'OPTIONS',
    1 => 'GET',
    2 => 'POST',
  ),
  'api_1_get_note' => 
  array (
    0 => 'GET',
    1 => 'PUT',
    2 => 'DELETE',
  ),
  'api_1_put_note' => 
  array (
    0 => 'GET',
    1 => 'PUT',
    2 => 'DELETE',
  ),
  'api_1_delete_note' => 
  array (
    0 => 'GET',
    1 => 'PUT',
    2 => 'DELETE',
  ),
);