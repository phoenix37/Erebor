'use strict';
/* Controllers */
var noteControllers = angular.module('noteControllers', []);
noteControllers.controller('CalendarController', ['$scope', '$http',
	function($scope, $http) {
		this.seriesNo = -1;
		var self = this;
		$http.get('http://localhost:8000/api/v1/notes.json').success(function(data){
			self.series = [data];
		});
		this.setSeriesNo = function(numb) {
			this.seriesNo = numb;
		};
		this.getSeries = function() {
			return this.series[this.seriesNo];
		};
		$scope.range = function(range) {
			var arr = [];
			for (var i = 0; i < range; i++) {
				arr += i+1;
			}
			return arr;
		};
		this.addSeries = function(object) {
			var idx = this.series.indexOf(object) + 1;
			this.series.splice(idx, 0, []);
		};

	}]);
noteControllers.controller('DropDownListController', ['$scope', function($scope) {
	this.clicked = false;
	$scope.ddlSelected = 'img/smile0.png';
	this.itemsList = [];
	for (var i = 1; i <= 4; i++)
		this.itemsList.push('img/smile'+ i +'.png');
	this.toggle = function() {
		this.clicked = !this.clicked;
	};
	this.select = function(item) {
		this.clicked = false;
		$scope.ddlSelected = item;
	};
}]);
noteControllers.controller('NoteFormController', ['$scope', '$http',
	function($scope, $http) {
		var getDate = function() {
			var d = new Date();
			var day = d.getDate();
			var mth = d.getMonth()+1;
			var year = d.getFullYear().toString();
			day = (day > 9) ? day.toString() : '0'+day;
			mth = (mth > 9) ? mth.toString() : '0'+mth;
			return year + '-' + mth + '-' + day;
		};
		this.init = function() {
			$scope.note = {
				"imgUrl": '',
				"date": '',
				"description": '',
				"stars": 0,
				"evaluated": true
			};
			$scope.note.stars = 0;
		};
		this.submit = function(series) {
			var note = $scope.note
			note.date = getDate();
			note.imgUrl = $scope.ddlSelected;
			$http.post('http://localhost:8000/api/v1/notes.json', note)
			.success(function(data) {
				note.img_url = note.imgUrl;
				series.push(note);
			});
			
			$scope.note = {
				"imgUrl": '',
				"date": '',
				"description": '',
				"stars": 0,
				"evaluated": true
			};
			$scope.note.stars = 0;
		};
	}]);
