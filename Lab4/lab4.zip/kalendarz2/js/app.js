'use strict';
/* Modules */
var app = angular.module('calendar', [
	'noteControllers',
	'noteDirectives'
]);
app.config(['$httpProvider', function($httpProvider) {
	$httpProvider.defaults.useXDomain = true;
	$httpProvider.defaults.headers.post['Accept'] = 'application/json, text/javascript';
	$httpProvider.defaults.headers.post['Content-Type'] = 'application/json; charset=utf-8';
	delete $httpProvider.defaults.headers.common['X-Requested-With'];
}]);