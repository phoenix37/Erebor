'use strict';
/* Directives */
var noteDirectives = angular.module('noteDirectives', []);
noteDirectives.directive('dropDownList', function() {
	return {
		restrict: 'A',
		templateUrl: 'partials/drop-down-list.html',
		controller: 'DropDownListController',
		controllerAs: 'ddlCtrl'
	};
});
noteDirectives.directive('noteForm', function() {
	return {
		restrict: 'E',
		templateUrl: 'partials/note-form.html',
		controller: 'NoteFormController',
		controllerAs: 'formCtrl'
	};
});